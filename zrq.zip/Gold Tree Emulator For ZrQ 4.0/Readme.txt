sql add this :

ALTER TABLE `permissions_ranks` ADD `cmd_viproomalert` ENUM('1','0') NOT NULL DEFAULT '0';
ALTER TABLE `permissions_ranks` ADD `cmd_warp` ENUM('1','0') NOT NULL DEFAULT '0';
